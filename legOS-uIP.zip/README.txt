The legOS.htm file tells exactly you how to install all the files.

After installation fo the lnpd, legOS and the Compiler:

Put the file in rcx_code into /legos/demo/
Put the files in pc_code into the applications drawer in the lnpd installation directory.
Just overwrite the Makefiles in the /legOS directory with the files in the Makefiles drawer.
Put the files from include and the kernel to the respective drawers.

after installation type in /legOS

make realclean
make depend
make
cd util
make strip
This will compile the whole kernel.
You have to recompile the whole kernel each time you ve made changes to the uip_user code.

Now,
go to /demo
type ../util/./firmdl3 -s ../boot/legOS.srec
This will download the kernel to the RCX.
(you dont really need -s (-s is just for the slow mode))

and...
type .././dll uip_rcx.lx
this will put the code to the rcx.

you can now start the code with the run-key and stop with the prgm-key.

Finally,
go to the lnpd directory.
Now start the lnpd and then the gateway with the & command,
ping 192.168.0.2 and smile ;-)
(you will see very silly stuff on the display while sending and receiving packets...)

Have fun !

Olaf Christ