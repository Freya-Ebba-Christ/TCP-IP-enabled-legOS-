/*
 * Copyright (c) 2002, Olaf Christ
 * http://www.informatik.fh-hamburg.de/~christ_o/
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Adam Dunkels.
 * 4. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior
 *    written permission.  
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
 *
 * This file is part of the uIP TCP/IP stack.
 *
 * $Id: uip_pc.c,v 1.2 2001/09/14 23:02:25 adam Exp $
 *
 */

#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/uio.h>
#include <sys/types.h>
#include "liblnp.h"
#include <semaphore.h>
#define BUFSIZE 240
unsigned char send_buf[BUFSIZE];
unsigned char receive_buf[BUFSIZE];
static unsigned char sbuf_len;
static unsigned char rbuf_len;
static int fd;
/*-----------------------------------------------------------------------------------*/
void
tundev_init(void)
{
  fd = open("/dev/tun0", O_RDWR);
  if(fd == -1) {
    perror("tun_dev: tundev_init: open");
    exit(1);
  }
#ifdef linux
  system("ifconfig tun0 inet 192.168.0.2 192.168.0.1");
  system("route add -net 192.168.0.0 netmask 255.255.255.0 dev tun0");
#else
  system("ifconfig tun0 inet 192.168.0.1 192.168.0.2");

#endif /* linux */
}
/*-----------------------------------------------------------------------------------*/

void
tundev_send(void)
{
  int ret;
  ret = write(fd,receive_buf, rbuf_len);
  if(ret == -1) {
    perror("tun_dev: tundev_done: write");
    exit(1);
  }
}  

/*-----------------------------------------------------------------------------------*/
unsigned int
tundev_read(void)
{
  fd_set fdset;
  struct timeval tv;
  int ret;

  tv.tv_sec = 0;
  tv.tv_usec = 0;
  FD_ZERO(&fdset);
  FD_SET(fd, &fdset);
  
  ret = select(fd + 1, &fdset, NULL, NULL, &tv);
  if(ret == 0) {
    return 0;
  } 
  ret = read(fd, send_buf, BUFSIZE);
  if(ret == -1) {
    perror("tun_dev: tundev_read: read");
  }
    
  return ret;
}
/*-----------------------------------------------------------------------------------*/
void handler(const unsigned char* data,unsigned char length)
{
memcpy(receive_buf,data,length);
rbuf_len=length;
	  tundev_send(); //forward packet to ip-address
}
/*-----------------------------------------------------------------------------------*/
int
main(void)
{

  lnp_tx_result result;

if ( lnp_init(0,0,0,0,0) )
    {
    	perror("lnp_init");	
    	exit(1);
    }

    else fprintf(stderr,"init OK\n");


  tundev_init();

lnp_integrity_set_handler(handler);

  while(1) {
    sbuf_len = tundev_read(); //ready packet from ip-address
    if(sbuf_len == 0) {
    } else 
     if(sbuf_len > 0) {
	result = lnp_integrity_write(send_buf,sbuf_len); //forward to RCX
	switch (result)
		{
        	case TX_SUCCESS:
		sbuf_len=0;
    		break;
   		case TX_FAILURE:
		printf("Collision\n");
		sbuf_len=0; // the packet is considered to be lost
        		break;
        	default:
        		perror("Transmit error");
        		exit(1);
        }

     }
    
  }
  return 0;
}
/*-----------------------------------------------------------------------------------*/

