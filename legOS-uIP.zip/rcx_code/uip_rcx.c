/*
 * Copyright (c) 2002, Olaf Christ
 * http://www.informatik.fh-hamburg.de/~christ_o/
 * All rights reserved. 
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met: 
 * 1. Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer. 
 * 2. Redistributions in binary form must reproduce the above copyright 
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the distribution. 
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by Adam Dunkels.
 * 4. The name of the author may not be used to endorse or promote
 *    products derived from this software without specific prior
 *    written permission.  
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  
 *
 * This file is part of the uIP TCP/IP stack.
 *
 * $Id: uip_rcx.c,v 1.2 2001/07/02 06:56:27 adam Exp $
 *
 */ 

#include <lnp.h> 
#include <conio.h> 
#include <sys/irq.h> 
#include <sys/h8.h> 
#include <tm.h> 
#include <dkey.h> 
#include <unistd.h> 
#include <lnp-logical.h> 
#include <sys/lnp-logical.h> 
#include <uip.h> 
#include <string.h> 
#include <semaphore.h>
char done;

static char result;
static unsigned char packet_length;
static unsigned char tmpbuf[UIP_BUFSIZE];
static sem_t packet_sem; //synchronization semaphore

wakeup_t prgmKeyCheck(wakeup_t data) {
	return dkey == KEY_PRGM;
}

void prepareData() {
		u8_t i;
		for (i = 0; i < 40; i++) {
			tmpbuf[i] = uip_buf[i];
		}
		for (i = 40; i < uip_len; i++) {
			tmpbuf[i] = uip_appdata[i - 40];
		}
	}

/*-----------------------------------------------------------------------------------*/

	/*
	The packet handler gets all integrity packets sent over the network.
	The handler sets uip_len to length
	(everytime a packet arrives, its passed to this handler)
	*/

	void packet_handler(const unsigned char * data, unsigned char length) {
		 if(packet_length>0 || length==0)
    		return;
		memcpy(uip_buf, data,length);
		uip_len = length; // set new length of packet
		packet_length = length;
		cputs("got one");
  		sem_post(&packet_sem);
	}

/*-----------------------------------------------------------------------------------*/

int sender(int argc, char* argv[]) {
	while (!done) {
		// wait for new packet
		packet_length = 0;
		sem_wait(&packet_sem);
		if (uip_len > 0) {
			uip_process(UIP_DATA);
			if (uip_len > 0) {
				cputs(">0");
				prepareData();
				result = lnp_integrity_write(tmpbuf, uip_len);
				if (result == TX_IDLE) {
					cputs("idle");
					msleep(10);
				}
				uip_len = 0;
			}
		}
	}
	return 0;
}
/*-----------------------------------------------------------------------------------*/
int main(int argc, char** argv) {
		uip_init();
		lnp_logical_range(0);
		lcd_clear();
		cputs("wait");
		uip_len = 0;
		lnp_integrity_set_handler(packet_handler);
		packet_length = 0;
		sem_init(&packet_sem,0,0);
		execi(sender, 0, NULL, PRIO_NORMAL, DEFAULT_STACK_SIZE);
		while (1) {
			if (prgmKeyCheck(0))
				break;
			// this program must be terminated by the prgm key !!!
		}
		done = 1;
		cputs("done");
  		sem_destroy(&packet_sem);
		return 0;
		// we re all done
	}
/*-----------------------------------------------------------------------------------*/

