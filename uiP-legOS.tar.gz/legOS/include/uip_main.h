#ifndef __UIP_MAIN_H__
#define __UIP_MAIN_H__

void uip_main(void);

#endif /* __UIP_MAIN_H__ */
